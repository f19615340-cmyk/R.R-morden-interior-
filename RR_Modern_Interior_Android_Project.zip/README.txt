R.R Modern Interior - Android Studio project

Project details
- App name: R.R Modern Interior
- Package: com.rrmoderninterior.app
- Theme: Black & Gold
- Business location: Ayodhya, Uttar Pradesh
- WhatsApp: +91 8738947315

Build an APK
1. Install Android Studio on a computer.
2. Open Android Studio > Open, then select this project folder.
3. Allow Gradle sync to finish. Internet is required the first time to download Android Gradle Plugin.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When complete, choose 'locate' in the notification. The APK is usually at:
   app/build/outputs/apk/debug/app-debug.apk

Notes
- This deliverable is the Android Studio source project, not a compiled APK.
- This environment does not have the Android SDK or Gradle installed, so an APK could not be compiled here.
- The design gallery loads sample interior inspiration photos from Unsplash and therefore needs internet.
- Booking and contact buttons open WhatsApp. The customer must review and press Send in WhatsApp.
- Confirm that the displayed business phone number and details are correct before publishing.
